package com.bhtt.attendance.ui.developer

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.bhtt.attendance.R              // <- adjust to your app's R class if the package differs
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/** Swap these for the fonts already in your project (e.g. Cinzel / Caveat). */
object DeveloperFonts {
    var heading: FontFamily = FontFamily.Serif
    var script: FontFamily = FontFamily.Cursive
}

private val Cyan = Color(0xFF22D3EE)
private val DescText = Color(0xFFC9C4EA)
private val GlassBorder = Brush.linearGradient(listOf(Color(0x8C22D3EE), Color(0x8C3B82F6), Color(0x8C8B5CF6), Color(0x8CEC4899)))
private val HeadingCyan = Brush.horizontalGradient(listOf(Color(0xFF22D3EE), Color(0xFF818CF8)))
private val HeadingLav = Brush.horizontalGradient(listOf(Color(0xFFC4B5FD), Color(0xFFF0ABFC)))
private val NameBrush = Brush.verticalGradient(listOf(Color.White, Color(0xFFC7D8FF), Color(0xFFA5B4FC)))
private val AccentBar = Brush.horizontalGradient(listOf(Color(0xFF22D3EE), Color(0xFF8B5CF6)))
private val GlassFill = Brush.linearGradient(listOf(Color(0x1A22D3EE), Color(0x294F46E5), Color(0x2EA855F7)))

/**
 * The whole Developer Details section. Drop it inside the Settings screen's scrolling column.
 * It does not draw a screen background and does not touch navigation.
 */
@Composable
fun DeveloperSection(
    modifier: Modifier = Modifier,
    versionName: String = "1.0.0",
    editionLabel: String = "2026-27 Academic Edition",
) {
    val resumed by rememberIsResumed()
    var signatureVisible by remember { mutableStateOf(false) }
    var aimVisible by remember { mutableStateOf(false) }

    Column(modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        DeveloperCard(signatureVisible = signatureVisible && resumed, onSignatureVisible = { signatureVisible = it })
        MessageCard()
        AimCard(
            active = aimVisible && resumed,
            modifier = Modifier.trackVisibility(0.25f) { aimVisible = it },
        )
        Footer(versionName, editionLabel)
    }
}

@Composable
private fun GlassCard(modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    Box(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(28.dp))
            .background(GlassFill)
            .border(BorderStroke(1.dp, GlassBorder), RoundedCornerShape(28.dp)),
    ) { content() }
}

@Composable
private fun DeveloperCard(signatureVisible: Boolean, onSignatureVisible: (Boolean) -> Unit) {
    GlassCard {
        // Real Earth artwork (res/drawable-nodpi/developer_earth.png), cropped not stretched.
        Image(
            painter = painterResource(R.drawable.developer_earth),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            alignment = Alignment.BottomCenter,
            modifier = Modifier.matchParentSize(),
        )
        Box(Modifier.matchParentSize().background(
            Brush.verticalGradient(0f to Color(0x5704081E), 0.55f to Color(0x80060A26), 1f to Color(0xDB080A24)),
        ))
        Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                Box(Modifier.width(48.dp).height(1.dp).background(Cyan.copy(alpha = 0.7f)))
                Text("DEVELOPER", style = TextStyle(brush = HeadingCyan, fontSize = 13.sp, letterSpacing = 4.sp), modifier = Modifier.padding(horizontal = 12.dp))
                Box(Modifier.width(48.dp).height(1.dp).background(Cyan.copy(alpha = 0.7f)))
            }
            Spacer(Modifier.height(14.dp))
            Box(Modifier.size(104.dp), contentAlignment = Alignment.Center) {
                Box(Modifier.size(104.dp).background(Brush.radialGradient(listOf(Color(0x553B82F6), Color.Transparent)), CircleShape))
                Image(painterResource(R.drawable.developer_logo), "BK logo", Modifier.size(88.dp).clip(CircleShape))
            }
            Spacer(Modifier.height(10.dp))
            Text(
                buildAnnotatedString {
                    withStyle(SpanStyle(fontSize = 30.sp)) { append("B") }
                    withStyle(SpanStyle(fontSize = 23.sp)) { append("HAWISHYA ") }
                    withStyle(SpanStyle(fontSize = 30.sp)) { append("K") }
                    withStyle(SpanStyle(fontSize = 23.sp)) { append("UMAR") }
                },
                style = TextStyle(brush = NameBrush, fontFamily = DeveloperFonts.heading, fontWeight = FontWeight.Bold, letterSpacing = 1.sp),
            )
            Spacer(Modifier.height(10.dp))
            Row(
                Modifier.clip(RoundedCornerShape(50)).border(1.dp, Color(0xFF3B82F6), RoundedCornerShape(50)).padding(horizontal = 18.dp, vertical = 7.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("</>", color = Cyan, fontSize = 14.sp, fontFamily = FontFamily.Monospace)
                Spacer(Modifier.width(8.dp))
                Text("App Developer & Creator", color = Color(0xFFBFD8FF), fontSize = 15.sp)
            }
            Spacer(Modifier.height(6.dp))
            AnimatedSignature(
                visible = signatureVisible,
                modifier = Modifier.trackVisibility(0.5f, onSignatureVisible),
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.weight(1f).height(1.dp).background(Cyan.copy(alpha = 0.5f)))
                Text("Better Apps for a Brighter Tomorrow", color = Color(0xFFD7E3FF), fontSize = 12.sp, fontStyle = FontStyle.Italic,
                    letterSpacing = 1.2.sp, textAlign = TextAlign.Center, modifier = Modifier.weight(3f).padding(horizontal = 8.dp))
                Box(Modifier.weight(1f).height(1.dp).background(Cyan.copy(alpha = 0.5f)))
            }
        }
    }
}

@Composable
private fun MessageCard() {
    GlassCard {
        Column(Modifier.padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(44.dp).clip(RoundedCornerShape(14.dp))
                        .background(Brush.linearGradient(listOf(Color(0xFFA78BFA), Color(0xFF7C3AED), Color(0xFFEC4899)))),
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Filled.Favorite, null, tint = Color.White, modifier = Modifier.size(24.dp)) }
                Spacer(Modifier.width(14.dp))
                Text("A MESSAGE FOR YOU", style = TextStyle(brush = HeadingLav, fontSize = 13.sp, letterSpacing = 3.sp))
                Box(Modifier.weight(1f).padding(start = 12.dp).height(1.dp).background(Color(0x668B5CF6)))
            }
            Spacer(Modifier.height(14.dp))
            Text("Thank you for using this app! 💜", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth()) {
                Box(Modifier.width(3.dp).height(80.dp).clip(RoundedCornerShape(2.dp)).background(Brush.verticalGradient(listOf(Color(0xFFA78BFA), Color(0xFF6366F1), Color(0xFF22D3EE)))))
                Text(
                    "I created this app with a simple goal — to make your daily life a little easier, more organized and more productive. Your support and trust mean a lot to me.",
                    color = DescText, fontSize = 15.sp, lineHeight = 22.sp, modifier = Modifier.padding(start = 12.dp),
                )
            }
        }
    }
}

@Composable
private fun AimCard(active: Boolean, modifier: Modifier = Modifier) {
    GlassCard(modifier) {
        Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1.25f)) {                    // text column never overlaps the rocket column
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TargetIcon(Modifier.size(30.dp))
                    Spacer(Modifier.width(12.dp))
                    Text("MY AIM", style = TextStyle(brush = HeadingCyan, fontSize = 14.sp, letterSpacing = 3.sp))
                }
                Box(Modifier.padding(vertical = 8.dp).width(64.dp).height(2.5.dp).clip(RoundedCornerShape(2.dp)).background(AccentBar))
                Text("To keep improving, add more useful features and create apps that truly make a difference.",
                    color = DescText, fontSize = 15.sp, lineHeight = 22.sp)
            }
            AimRocket(active = active, modifier = Modifier.weight(1f).height(130.dp))
        }
    }
}

@Composable
private fun TargetIcon(modifier: Modifier) {
    Canvas(modifier) {
        val c = center; val r = size.minDimension / 2f
        val brush = Brush.linearGradient(listOf(Cyan, Color(0xFF8B5CF6)))
        drawCircle(brush, r * 0.92f, c, style = Stroke(r * 0.12f))
        drawCircle(brush, r * 0.60f, c, style = Stroke(r * 0.12f))
        drawCircle(brush, r * 0.22f, c)
        drawLine(brush, c, Offset(size.width * 0.96f, size.height * 0.04f), strokeWidth = r * 0.12f)
    }
}

@Composable
private fun Footer(versionName: String, editionLabel: String) {
    Column(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.width(80.dp).height(1.dp).background(Brush.horizontalGradient(listOf(Color.Transparent, Cyan))))
            StarDot(Modifier.padding(horizontal = 10.dp).size(18.dp))
            Box(Modifier.width(80.dp).height(1.dp).background(Brush.horizontalGradient(listOf(Cyan, Color.Transparent))))
        }
        Spacer(Modifier.height(8.dp))
        Text("Thank you for being here! 😊", style = TextStyle(brush = Brush.horizontalGradient(listOf(Color(0xFF22D3EE), Color(0xFF60A5FA), Color(0xFFC084FC))), fontFamily = DeveloperFonts.script, fontSize = 28.sp, fontWeight = FontWeight.Bold))
        Spacer(Modifier.height(10.dp))
        Text("Made with 💜 by Bhawishya Kumar", color = Color(0xFFB8BEDD), fontSize = 14.sp)
        Spacer(Modifier.height(6.dp))
        Text("v$versionName • $editionLabel", color = Color(0xFF8A90B5), fontSize = 12.sp)
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
private fun StarDot(modifier: Modifier) {
    Canvas(modifier) {
        val c = center; val ro = size.minDimension / 2f; val ri = ro * 0.42f
        val p = Path()
        for (i in 0 until 10) {
            val r = if (i % 2 == 0) ro else ri
            val a = (-PI / 2 + i * PI / 5).toFloat()
            val x = c.x + r * cos(a); val y = c.y + r * sin(a)
            if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
        }
        p.close()
        drawPath(p, Color(0xFF5B8CFF))
    }
}
