package com.bhtt.attendance.ui.developer

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.vector.PathParser
import kotlin.math.PI
import kotlin.math.sin

private const val CYCLE_MS = 3600

// Rocket drawn in a 160 x 200 viewBox, nose pointing up. Every part is its own SVG path.
private val BODY = "M80 14 C104 38 112 78 108 120 L52 120 C48 78 56 38 80 14 Z"
private val NOSE = "M80 14 C90 24 97 36 101 50 L59 50 C63 36 70 24 80 14 Z"
private val FIN_L = "M54 92 C40 100 30 118 28 142 L52 126 Z"
private val FIN_R = "M106 92 C120 100 130 118 132 142 L108 126 Z"
private val FIN_C = "M72 120 L80 148 L88 120 Z"
private val BAND_1 = "M54 100 L106 100"
private val BAND_2 = "M52 110 L108 110"
private val NOZZLE = "M62 120 L98 120 L92 134 L68 134 Z"
private val FLAME_OUT = "M68 134 C66 160 74 176 80 198 C86 176 94 160 92 134 Z"
private val FLAME_IN = "M73 134 C72 150 77 162 80 176 C83 162 88 150 87 134 Z"

private val Cyan = Color(0xFF22D3EE)
private val Blue = Color(0xFF3B82F6)
private val Violet = Color(0xFF8B5CF6)

/**
 * Animated vector rocket + clouds. [active] should be true only while the card is on screen and
 * the app is resumed; when it flips to false the rocket eases back to its resting pose and the
 * animation loop stops (no CPU use while idle).
 */
@Composable
fun AimRocket(active: Boolean, modifier: Modifier = Modifier) {
    val phase = remember { Animatable(0f) }
    LaunchedEffect(active) {
        if (active) {
            while (true) {
                phase.snapTo(phase.value % 1f)
                phase.animateTo(phase.value + 1f, tween(CYCLE_MS, easing = LinearEasing))
            }
        } else {
            val rest = if (phase.value % 1f > 0.5f) kotlin.math.ceil(phase.value) else kotlin.math.floor(phase.value)
            phase.animateTo(rest, tween(450))
        }
    }
    val body = remember { listOf(BODY, NOSE, FIN_L, FIN_R, FIN_C, NOZZLE).map { PathParser().parsePathString(it).toPath() } }
    val bands = remember { listOf(BAND_1, BAND_2).map { PathParser().parsePathString(it).toPath() } }
    val flameOut = remember { PathParser().parsePathString(FLAME_OUT).toPath() }
    val flameIn = remember { PathParser().parsePathString(FLAME_IN).toPath() }

    Canvas(modifier) {
        val t = phase.value * 2f * PI.toFloat()           // integer multiples of t loop seamlessly
        val float = sin(t)                                 // -1..1 idle bob
        val tilt = sin(t + 0.8f) * 3f                      // +-3 degrees
        val flicker = 1f + 0.10f * sin(t * 5f) + 0.06f * sin(t * 8f + 1f)
        val glow = 0.5f + 0.5f * sin(t * 2f)

        // clouds (behind rocket, slow horizontal drift)
        val cw = size.width
        val cy = size.height * 0.90f
        val drift = sin(t) * cw * 0.02f
        listOf(
            Triple(0.28f, 0.0f, 0.15f), Triple(0.45f, -0.05f, 0.19f), Triple(0.62f, 0.02f, 0.16f),
            Triple(0.80f, -0.02f, 0.13f), Triple(0.16f, 0.03f, 0.10f),
        ).forEachIndexed { i, (x, dy, r) ->
            val c = Offset(cw * x + drift * (if (i % 2 == 0) 1 else -1), cy + size.height * dy)
            drawCircle(
                Brush.radialGradient(listOf(Blue.copy(alpha = 0.55f), Violet.copy(alpha = 0.22f), Color.Transparent), c, cw * r),
                cw * r, c,
            )
        }

        // rocket: fit the 160x200 viewBox into the upper ~85% of the box, then tilt toward upper-right
        val fit = minOf(size.width / 160f, size.height * 0.86f / 200f) * 0.92f
        val left = (size.width - 160f * fit) / 2f
        val top = size.height * 0.02f + float * -size.height * 0.025f
        translate(left, top) {
            rotate(32f + tilt, pivot = Offset(80f * fit, 110f * fit)) {
                scale(fit, fit, pivot = Offset.Zero) { drawRocket(body, bands, flameOut, flameIn, flicker, glow) }
            }
        }
    }
}

private fun DrawScope.drawRocket(
    parts: List<androidx.compose.ui.graphics.Path>,
    bands: List<androidx.compose.ui.graphics.Path>,
    flameOut: androidx.compose.ui.graphics.Path,
    flameIn: androidx.compose.ui.graphics.Path,
    flicker: Float,
    glow: Float,
) {
    val edge = Brush.linearGradient(listOf(Cyan, Blue, Violet), Offset(0f, 0f), Offset(160f, 200f))
    val fill = Brush.verticalGradient(listOf(Color(0x5538BDF8), Color(0x331E3A8A)), 0f, 140f)
    val line = Stroke(2.2f, cap = StrokeCap.Round, join = StrokeJoin.Round)
    val halo = Stroke(7f, cap = StrokeCap.Round, join = StrokeJoin.Round)

    // exhaust glow (pulsing)
    val ec = Offset(80f, 150f)
    drawCircle(Brush.radialGradient(listOf(Cyan.copy(alpha = 0.18f + 0.30f * glow), Color.Transparent), ec, 46f), 46f, ec)

    // flame, flickering vertically from the nozzle
    scale(1f, flicker, pivot = Offset(80f, 134f)) {
        drawPath(flameOut, Brush.verticalGradient(listOf(Color(0xCC22D3EE), Color(0x00508CFF)), 134f, 198f), style = androidx.compose.ui.graphics.drawscope.Fill)
        drawPath(flameOut, edge, alpha = 0.8f, style = Stroke(1.6f))
        drawPath(flameIn, Brush.verticalGradient(listOf(Color.White, Color(0x0022D3EE)), 134f, 176f))
    }

    parts.forEach { p ->
        drawPath(p, fill)
        drawPath(p, edge, alpha = 0.22f, style = halo)
        drawPath(p, edge, style = line)
    }
    bands.forEach { drawPath(it, edge, alpha = 0.8f, style = Stroke(1.6f, cap = StrokeCap.Round)) }

    // window
    val wc = Offset(80f, 72f)
    drawCircle(edge, 14f, wc, style = Stroke(2.4f))
    drawCircle(Brush.radialGradient(listOf(Color(0xFF7DD3FC), Color(0xFF1D4ED8)), wc, 9f), 9f, wc)
    drawCircle(Color.White.copy(alpha = 0.7f), 2.2f, Offset(77f, 69f))
}
