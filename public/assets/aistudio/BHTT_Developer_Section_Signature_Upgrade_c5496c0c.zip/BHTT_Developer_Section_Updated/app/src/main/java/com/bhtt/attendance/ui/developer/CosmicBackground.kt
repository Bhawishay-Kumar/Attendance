package com.bhtt.attendance.ui.developer

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import kotlin.random.Random

/**
 * Standalone cosmic backdrop for the demo screen. In your real app keep using the existing
 * starfield/background component instead; DeveloperSection does not need this file.
 */
@Composable
fun CosmicBackground(modifier: Modifier = Modifier) {
    val stars = remember {
        val r = Random(7)
        List(140) { Triple(r.nextFloat(), r.nextFloat(), r.nextFloat()) }
    }
    Canvas(modifier.fillMaxSize()) {
        drawRect(Brush.verticalGradient(listOf(Color(0xFF03030F), Color(0xFF060A24), Color(0xFF04051A))))
        val a = Offset(size.width * 0.15f, size.height * 0.30f)
        val b = Offset(size.width * 0.90f, size.height * 0.70f)
        drawCircle(Brush.radialGradient(listOf(Color(0x552B3BFF), Color.Transparent), a, size.width * 0.8f), size.width * 0.8f, a)
        drawCircle(Brush.radialGradient(listOf(Color(0x449333EA), Color.Transparent), b, size.width * 0.7f), size.width * 0.7f, b)
        stars.forEach { (x, y, s) ->
            drawCircle(Color.White.copy(alpha = 0.25f + 0.6f * s), 0.6f + 1.6f * s, Offset(x * size.width, y * size.height))
        }
    }
}
