package com.bhtt.attendance.ui.developer

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/**
 * Self-contained screen for trying the section on its own (set it as setContent in a scratch
 * Activity). In the real Settings screen, call DeveloperSection() inside your existing
 * scroll container instead and keep your existing bottom navigation.
 */
@Composable
fun DeveloperDemoScreen() {
    Box(Modifier.fillMaxSize()) {
        CosmicBackground()
        Column(Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState())) {
            // Spacer pushes the section down so the "starts when visible" behaviour is easy to see.
            Spacer(Modifier.height(520.dp))
            DeveloperSection()
            Spacer(Modifier.height(100.dp).navigationBarsPadding().padding(bottom = 8.dp))
        }
    }
}
