# BHTT Developer Section (updated, drop-in package)

Jetpack Compose implementation of the redesigned Developer Details section, matching the approved web preview.
IMPORTANT: this is the standalone package, not your full app. Your app source has not been provided yet, so nothing
here is wired into Settings. When you send the app code it can be merged into the real project.

## What changed in this version
- Signature is now the EXACT traced artwork from your reference image (pixels, letterforms, gradient, glow, underline),
  not hand-drawn paths. Old hand-authored SignatureData.kt was removed.
- Signature animation rebuilt to write like a real hand (about 6.4 s):
  - Letter by letter: B, h, a, w, i, s, h, y, a, then K, u, m, a, r. Each letter is finished before the next starts.
  - Human timing: short pen-lift pause between letters, longer pause between "Bhawishya" and "Kumar", a pause before the
    underline, gentle slow-fast-slow pace inside each letter, and a fast underline flick that decelerates at the end.
  - Shine: the freshest stroke glows white-hot and cools over about 0.2 s, so the last stroke of every letter shines;
    each finished letter blooms once; a soft glowing pen tip follows the writing (hidden while the pen is "lifted");
    after the final stroke a light shimmer sweeps across the whole signature, then the end sparkle.
- Calmer gradients: gradient card borders (about 55% opacity), tinted glass fill, gradient headings, lighter scrim so the
  Earth artwork stays prominent, softer logo glow.

## Files (app/src/main/java/com/bhtt/attendance/ui/developer/)
- DeveloperSection.kt   Developer card, message card, MY AIM card, footer.
- AnimatedSignature.kt  SignatureRenderer (decode assets, per-frame reveal, pen tip, sparkle) + AnimatedSignature composable.
- AimRocket.kt          Vector rocket and clouds (unchanged).
- VisibilityUtils.kt    trackVisibility() and rememberIsResumed() (unchanged).
- CosmicBackground.kt, DeveloperDemoScreen.kt   Demo only; skip in the real app.

## Assets
res/drawable-nodpi/: developer_earth.png (your Earth image), developer_logo.png (crop from screenshot, low resolution,
replace with the original), signature_art.png (traced signature, RGBA), signature_time.png (16-bit pen time map,
R = high byte, G = low byte; keep it lossless).
res/raw/signature_pen.json: 900 pen-tip samples [x, y, alpha] in artwork pixels, sampled evenly on the animation clock
(alpha 0 while the pen is lifted).
res/raw/signature_timing.json (NEW): total duration in ms plus the start/end time of each of the 15 strokes groups.
signature_time.png: the blue channel now stores the letter id (0..14) of each pixel.

## How the signature works
Each ink pixel has a time value (its position along the pen path). Per frame, pixels whose time is below the current
progress are shown (with a very short soft edge); only ink pixels (about 60k) are visited, then the 1070 x 260 bitmap is
drawn scaled. Progress runs on one linear Animatable (duration read from signature_timing.json); all pacing is baked into the time map.
- Auto-start: first time the signature is at least 50% visible and the app is resumed (once per composition, i.e. per screen visit).
- Double-tap: LaunchedEffect keyed on replayToken restarts, cancelling the old run, resets the pen and writes from 0. Single tap does nothing.

## Needed from your project
Package/R import (`com.bhtt.attendance`), compose ui/foundation/material3, lifecycle-runtime. Set DeveloperFonts.heading and
DeveloperFonts.script to your own fonts. No new dependencies (org.json is part of Android).

## Verification actually performed
- Earlier version, web preview (Chromium via Playwright, 390x844): played the full animation. 155 frames in 4.40 s, progress and revealed ink
  strictly monotonic (no flicker or going backwards), render cost about 2.4 ms per frame, no script errors. Auto-start did not
  fire at 30% visibility and did fire when visible. Single tap did not restart; double tap restarted from 0 and finished.
  Recorded video frames were reviewed.
- Kotlin: static checks only (balanced brackets, unused imports, asset/resource names exist).
## NOT performed
- The Kotlin code was NOT compiled or run (no Kotlin compiler, Gradle or Android SDK in the authoring environment).
  Expect to fix small API or import issues on first build, and judge on-device smoothness yourself.
- The pen order is approximate: it is derived automatically from a skeleton of the image, so a few strokes (for example some
  h and y loops) are written in a slightly different order than a human would.
- Google Fonts in the web preview could not load in the test sandbox, so fonts there were fallbacks.

## Update note (this revision)
- Verified: the new time map and timing/pen files were generated and checked with a Python simulation of the renderer
  (frame contact sheets at 0.6 s steps: letters complete in order, shine and pen tip follow the stroke).
- NOT verified: the Kotlin was still not compiled or run on a device. Tunables are the constants at the top of
  AnimatedSignature.kt (TRAIL, TRAIL_GAIN, PULSE, PULSE_GAIN, SHIMMER_MS); pacing and pauses live in the generated assets.
- Letter boundaries are x-ranges on the traced artwork, so ligature pixels and the h/y loops are assigned to whichever
  letter region they sit in; a few strokes inside a letter may still be written in a slightly different order than a person would.
