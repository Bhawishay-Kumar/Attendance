package com.example.ui.bunk

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.bunk.BunkDayEntry
import com.example.data.bunk.BunkDayKind
import com.example.data.bunk.BunkOption
import com.example.data.bunk.BunkOverview
import com.example.data.bunk.SubjectImpact
import com.example.ui.components.loadIn
import com.example.ui.components.rememberEntranceTracker
import com.example.ui.theme.LocalGlassTheme
import com.example.ui.theme.OutfitFontFamily
import com.example.ui.theme.PlusJakartaSansFontFamily

@Composable
fun BunkOptionDetails(option: BunkOption, overview: BunkOverview, onBack: () -> Unit) {
    val glass = LocalGlassTheme.current
    val tracker = rememberEntranceTracker()
    val accent = rankAccent(glass, option.rank)
    LazyColumn(
        modifier = Modifier.fillMaxSize().testTag("bunk_details"),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, bottom = 40.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth().statusBarsPadding().padding(top = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(40.dp).clip(CircleShape).background(glass.cardSurface).clickable(onClick = onBack).testTag("bunk_details_back"),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = glass.textPrimary) }
                Column(Modifier.padding(start = 12.dp)) {
                    Text(rankTitle(option.rank), fontFamily = PlusJakartaSansFontFamily, fontSize = 11.sp, color = accent, fontWeight = FontWeight.SemiBold)
                    Text(rangeLabel(option.start, option.end), fontFamily = OutfitFontFamily, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = glass.textPrimary)
                }
            }
        }
        item {
            Box(Modifier.loadIn(0, tracker)) {
                BunkGlassCard(accent = accent) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        SectionTitle("Leave summary")
                        DateStrip(option)
                        StripLegend()
                        SummaryRow("Start", "${fullWeekday(option.start)}, ${option.start.dayOfMonth} ${shortMonth(option.start)}")
                        SummaryRow("End", "${fullWeekday(option.end)}, ${option.end.dayOfMonth} ${shortMonth(option.end)}")
                        SummaryRow("Consecutive days off", option.calendarDays.toString())
                        SummaryRow("Working days missed", option.workingDaysMissed.toString())
                        SummaryRow("Classes missed", "${option.classesMissed} (${option.weightedMissed} weighted)")
                        SummaryRow("Weekend days included", option.weekendDays.toString())
                        SummaryRow("Official holidays included", option.holidayDays.toString())
                        if (option.noClassDays > 0) SummaryRow("No-class days included", option.noClassDays.toString())
                    }
                }
            }
        }
        item {
            Box(Modifier.loadIn(1, tracker)) {
                BunkGlassCard {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        SectionTitle("Daily breakdown")
                        option.days.forEach { DayRow(it) }
                    }
                }
            }
        }
        item {
            Box(Modifier.loadIn(2, tracker)) {
                BunkGlassCard {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        SectionTitle("Overall attendance impact")
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            StatBlock("Current", option.currentPercent?.let { "${pct(it)}%" } ?: "—", glass.textPrimary, Modifier.weight(1f))
                            StatBlock("Projected", "${pct(option.projectedPercent)}%", glass.emeraldNeon, Modifier.weight(1f),
                                "${option.projectedAttended}/${option.projectedConducted}")
                            StatBlock("Target", "${option.requiredTarget}%", glass.textPrimary, Modifier.weight(1f),
                                "Exam ${overview.examTarget} · Stipend ${overview.stipendTarget}")
                        }
                        AttendanceBar(option.projectedPercent, option.requiredTarget, glass.emeraldNeon)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("Safety margin ${signed(option.marginPoints)} points", fontFamily = PlusJakartaSansFontFamily, fontSize = 12.sp, color = glass.textSecondary)
                            TierChip(option.tier)
                        }
                    }
                }
            }
        }
        item {
            Box(Modifier.loadIn(3, tracker)) {
                BunkGlassCard {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        SectionTitle("Subject-wise impact")
                        if (option.subjects.isEmpty()) {
                            Text("No subject is affected.", fontFamily = PlusJakartaSansFontFamily, fontSize = 12.sp, color = glass.textMuted)
                        }
                        option.subjects.forEach { SubjectRow(it, option.requiredTarget) }
                    }
                }
            }
        }
        item {
            Box(Modifier.loadIn(4, tracker)) {
                BunkGlassCard(accent = accent) {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        SectionTitle("Why this option")
                        Text(option.explanation, fontFamily = PlusJakartaSansFontFamily, fontSize = 13.sp, color = glass.textSecondary,
                            modifier = Modifier.testTag("bunk_explanation"))
                        Text(
                            "Month-end projection for ${overview.monthLabel}, not an all-time forecast. Future attendance is not guaranteed.",
                            fontFamily = PlusJakartaSansFontFamily, fontSize = 11.sp, color = glass.textMuted
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    val glass = LocalGlassTheme.current
    Text(text, fontFamily = OutfitFontFamily, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = glass.textPrimary)
}

@Composable
private fun SummaryRow(label: String, value: String) {
    val glass = LocalGlassTheme.current
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, fontFamily = PlusJakartaSansFontFamily, fontSize = 12.sp, color = glass.textMuted)
        Text(value, fontFamily = PlusJakartaSansFontFamily, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = glass.textPrimary)
    }
}

@Composable
private fun DayRow(e: BunkDayEntry) {
    val glass = LocalGlassTheme.current
    val color = dayKindColor(glass, e.kind)
    Column(
        Modifier.fillMaxWidth().clip(androidx.compose.foundation.shape.RoundedCornerShape(14.dp))
            .background(color.copy(alpha = 0.08f)).padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("${shortWeekday(e.date)}, ${e.date.dayOfMonth} ${shortMonth(e.date)}", fontFamily = OutfitFontFamily, fontWeight = FontWeight.SemiBold,
                fontSize = 14.sp, color = glass.textPrimary, modifier = Modifier.weight(1f))
            BunkChip(dayKindLabel(e.kind), color)
        }
        if (e.kind == BunkDayKind.HOLIDAY && e.label != null) {
            Text(e.label, fontFamily = PlusJakartaSansFontFamily, fontSize = 12.sp, color = glass.textSecondary)
        }
        if (e.kind == BunkDayKind.BUNK) {
            Text("${e.classesMissed} classes missed · ${e.subjectsAffected.joinToString()}", fontFamily = PlusJakartaSansFontFamily,
                fontSize = 12.sp, fontWeight = FontWeight.Medium, color = glass.crimsonRose)
            e.sessions.forEach { s ->
                Text(
                    "${s.periodLabel} · ${s.subject.shortName}" + when {
                        s.isAutoCredited -> " · auto-credited, unchanged"
                        else -> " · ${s.weight} credit${if (s.weight > 1) "s" else ""} missed"
                    },
                    fontFamily = PlusJakartaSansFontFamily, fontSize = 11.sp, color = glass.textMuted
                )
            }
        } else if (e.kind == BunkDayKind.NO_CLASS_DAY) {
            Text("No manually attended classes scheduled", fontFamily = PlusJakartaSansFontFamily, fontSize = 11.sp, color = glass.textMuted)
        }
    }
}

@Composable
private fun SubjectRow(s: SubjectImpact, target: Int) {
    val glass = LocalGlassTheme.current
    val c = statusColor(glass, s.status)
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(s.subject.shortName, fontFamily = OutfitFontFamily, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = glass.textPrimary)
                Text(s.subject.code, fontFamily = PlusJakartaSansFontFamily, fontSize = 10.5.sp, color = glass.textMuted)
            }
            BunkChip(statusLabel(s.status), c)
        }
        Text(
            "Now ${s.currentAttended}/${s.currentConducted}" + (s.currentPercent?.let { " (${pct(it)}%)" } ?: "") +
                "  →  ${s.projectedAttended}/${s.projectedConducted} (${pct(s.projectedPercent)}%)",
            fontFamily = PlusJakartaSansFontFamily, fontSize = 12.sp, color = glass.textSecondary
        )
        Text("${s.missedWeight} weighted session${if (s.missedWeight > 1) "s" else ""} missed · target $target%",
            fontFamily = PlusJakartaSansFontFamily, fontSize = 11.sp, color = glass.textMuted)
    }
}
