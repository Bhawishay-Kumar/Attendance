package com.example.ui.bunk

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.bunk.BunkDayEntry
import com.example.data.bunk.BunkDayKind
import com.example.data.bunk.BunkOption
import com.example.data.bunk.BunkPlannerEngine
import com.example.data.bunk.SafetyTier
import com.example.data.bunk.SubjectStatus
import com.example.ui.settings.rememberMotionEnabled
import com.example.ui.theme.GlassThemeTokens
import com.example.ui.theme.LocalGlassTheme
import com.example.ui.theme.OutfitFontFamily
import com.example.ui.theme.PlusJakartaSansFontFamily
import kotlinx.coroutines.delay
import java.time.LocalDate
import java.time.format.TextStyle
import java.util.Locale

// ---------------------------------------------------------------------------------------------
// Formatting helpers (display only; eligibility is decided by raw ratios in the engine)
// ---------------------------------------------------------------------------------------------

internal fun pct(value: Double): String = BunkPlannerEngine.fmt(value)

internal fun signed(value: Double): String {
    val s = BunkPlannerEngine.fmt(value)
    return if (value >= 0.0) "+$s" else s
}

internal fun shortWeekday(d: LocalDate): String = d.dayOfWeek.getDisplayName(TextStyle.SHORT, Locale.ENGLISH)
internal fun fullWeekday(d: LocalDate): String = d.dayOfWeek.getDisplayName(TextStyle.FULL, Locale.ENGLISH)
internal fun shortMonth(d: LocalDate): String = d.month.getDisplayName(TextStyle.SHORT, Locale.ENGLISH)

internal fun rangeLabel(start: LocalDate, end: LocalDate): String =
    if (start == end) "${shortWeekday(start)} ${start.dayOfMonth} ${shortMonth(start)}"
    else if (start.month == end.month) "${shortWeekday(start)} ${start.dayOfMonth} – ${shortWeekday(end)} ${end.dayOfMonth} ${shortMonth(end)}"
    else "${start.dayOfMonth} ${shortMonth(start)} – ${end.dayOfMonth} ${shortMonth(end)}"

internal fun rankTitle(rank: Int): String = when (rank) {
    1 -> "Best Option"
    2 -> "Second Option"
    else -> "Third Option"
}

internal fun dayKindLabel(kind: BunkDayKind): String = when (kind) {
    BunkDayKind.BUNK -> "Bunk Day"
    BunkDayKind.WEEKEND -> "Weekend"
    BunkDayKind.HOLIDAY -> "Official Holiday"
    BunkDayKind.NO_CLASS_DAY -> "No Class Day"
}

internal fun rankAccent(glass: GlassThemeTokens, rank: Int): Color = when (rank) {
    1 -> glass.royalIndigo
    2 -> glass.electricViolet
    else -> glass.electricTeal
}

internal fun pctColor(glass: GlassThemeTokens, value: Double, exam: Int, stipend: Int): Color = when {
    value >= maxOf(exam, stipend) -> glass.emeraldNeon
    value >= exam.coerceAtMost(stipend) -> glass.amberGold
    else -> glass.crimsonRose
}

internal fun statusColor(glass: GlassThemeTokens, s: SubjectStatus): Color = when (s) {
    SubjectStatus.ON_TRACK -> glass.emeraldNeon
    SubjectStatus.BELOW_STIPEND -> glass.amberGold
    SubjectStatus.BELOW_EXAM -> glass.crimsonRose
}

internal fun statusLabel(s: SubjectStatus): String = when (s) {
    SubjectStatus.ON_TRACK -> "On track"
    SubjectStatus.BELOW_STIPEND -> "Below stipend target"
    SubjectStatus.BELOW_EXAM -> "Below exam target"
}

internal fun dayKindColor(glass: GlassThemeTokens, kind: BunkDayKind): Color = when (kind) {
    BunkDayKind.BUNK -> glass.crimsonRose
    BunkDayKind.WEEKEND -> glass.royalIndigo
    BunkDayKind.HOLIDAY -> glass.amberGold
    BunkDayKind.NO_CLASS_DAY -> glass.electricTeal
}

// ---------------------------------------------------------------------------------------------
// Building blocks
// ---------------------------------------------------------------------------------------------

@Composable
internal fun BunkGlassCard(
    modifier: Modifier = Modifier,
    accent: Color? = null,
    content: @Composable () -> Unit
) {
    val glass = LocalGlassTheme.current
    val shape = RoundedCornerShape(22.dp)
    Box(
        modifier = modifier
            .fillMaxWidth()
            .shadow(if (glass.isDark) 0.dp else 6.dp, shape, ambientColor = Color(0x1A5B5BD6), spotColor = Color(0x1A5B5BD6))
            .clip(shape)
            .background(glass.cardSurface)
            .border(1.dp, accent?.copy(alpha = 0.45f) ?: glass.cardBorder, shape)
            .padding(16.dp)
    ) { content() }
}

@Composable
internal fun BunkChip(text: String, color: Color, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(50))
            .background(color.copy(alpha = 0.16f))
            .border(1.dp, color.copy(alpha = 0.35f), RoundedCornerShape(50))
            .padding(horizontal = 9.dp, vertical = 3.dp)
    ) {
        Text(text, fontFamily = PlusJakartaSansFontFamily, fontSize = 10.5.sp, fontWeight = FontWeight.SemiBold, color = color)
    }
}

@Composable
internal fun StatBlock(label: String, value: String, valueColor: Color, modifier: Modifier = Modifier, sub: String? = null) {
    val glass = LocalGlassTheme.current
    Column(modifier = modifier) {
        Text(value, fontFamily = OutfitFontFamily, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = valueColor)
        Text(label, fontFamily = PlusJakartaSansFontFamily, fontSize = 11.sp, color = glass.textMuted)
        if (sub != null) Text(sub, fontFamily = PlusJakartaSansFontFamily, fontSize = 10.sp, color = glass.textMuted)
    }
}

/** A thin progress bar with a target tick. The fill animates unless the user disabled animations. */
@Composable
internal fun AttendanceBar(value: Double, target: Int, color: Color, modifier: Modifier = Modifier) {
    val glass = LocalGlassTheme.current
    val motion = rememberMotionEnabled()
    val fraction by animateFloatAsState(
        targetValue = (value / 100.0).toFloat().coerceIn(0f, 1f),
        animationSpec = if (motion) tween(700, easing = FastOutSlowInEasing) else tween(0),
        label = "attBar"
    )
    Box(modifier = modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(50)).background(glass.cardBorder)) {
        Box(Modifier.fillMaxWidth(fraction).height(8.dp).clip(RoundedCornerShape(50)).background(color))
        Box(
            Modifier
                .fillMaxWidth((target / 100f).coerceIn(0f, 1f))
                .height(8.dp)
        ) {
            Box(
                Modifier
                    .align(Alignment.CenterEnd)
                    .width(2.dp)
                    .height(8.dp)
                    .background(glass.textPrimary.copy(alpha = 0.75f))
            )
        }
    }
}

/** One date of the break. Red = you must miss it; the others are already free. */
@Composable
internal fun DateChip(entry: BunkDayEntry, index: Int) {
    val glass = LocalGlassTheme.current
    val motion = rememberMotionEnabled()
    var shown by remember { mutableStateOf(!motion) }
    LaunchedEffect(Unit) {
        if (motion) { delay(index * 35L); shown = true }
    }
    val a by animateFloatAsState(
        targetValue = if (shown) 1f else 0f,
        animationSpec = spring(Spring.DampingRatioLowBouncy, Spring.StiffnessMediumLow),
        label = "chipIn"
    )
    val color = dayKindColor(glass, entry.kind)
    val isBunk = entry.kind == BunkDayKind.BUNK
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .graphicsLayer { alpha = a; scaleX = 0.85f + 0.15f * a; scaleY = 0.85f + 0.15f * a }
            .width(46.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(color.copy(alpha = if (isBunk) 0.22f else 0.10f))
            .border(1.dp, color.copy(alpha = if (isBunk) 0.7f else 0.3f), RoundedCornerShape(14.dp))
            .padding(vertical = 7.dp)
    ) {
        Text(shortWeekday(entry.date), fontFamily = PlusJakartaSansFontFamily, fontSize = 10.sp, color = glass.textSecondary)
        Text(entry.date.dayOfMonth.toString(), fontFamily = OutfitFontFamily, fontSize = 17.sp, fontWeight = FontWeight.Bold, color = glass.textPrimary)
        Text(
            when (entry.kind) {
                BunkDayKind.BUNK -> "Absent"
                BunkDayKind.WEEKEND -> "Free"
                BunkDayKind.HOLIDAY -> "Holiday"
                BunkDayKind.NO_CLASS_DAY -> "No class"
            },
            fontFamily = PlusJakartaSansFontFamily, fontSize = 9.sp, fontWeight = FontWeight.SemiBold, color = color, textAlign = TextAlign.Center
        )
    }
}

@Composable
internal fun DateStrip(option: BunkOption) {
    val scroll = rememberScrollState()
    Row(
        modifier = Modifier.horizontalScroll(scroll),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        option.days.forEachIndexed { i, e -> DateChip(e, i) }
    }
}

@Composable
internal fun StripLegend() {
    val glass = LocalGlassTheme.current
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
        listOf(
            "You miss" to glass.crimsonRose,
            "Weekend" to glass.royalIndigo,
            "Holiday" to glass.amberGold
        ).forEach { (t, c) ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.width(8.dp).height(8.dp).clip(RoundedCornerShape(50)).background(c))
                Spacer(Modifier.width(4.dp))
                Text(t, fontFamily = PlusJakartaSansFontFamily, fontSize = 10.sp, color = glass.textMuted)
            }
        }
    }
}

@Composable
internal fun TierChip(tier: SafetyTier) {
    val glass = LocalGlassTheme.current
    if (tier == SafetyTier.COMFORTABLE) BunkChip("Comfortable", glass.emeraldNeon) else BunkChip("Tight", glass.amberGold)
}
