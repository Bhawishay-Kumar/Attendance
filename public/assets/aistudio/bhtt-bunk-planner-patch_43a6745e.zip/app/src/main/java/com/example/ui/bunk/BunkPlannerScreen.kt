package com.example.ui.bunk

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.bunk.BunkOption
import com.example.data.bunk.BunkOverview
import com.example.data.bunk.BunkPlannerResult
import com.example.data.bunk.NoSafeReason
import com.example.data.bunk.SubjectStatus
import com.example.ui.components.StarfieldCanvas
import com.example.ui.components.loadIn
import com.example.ui.components.rememberEntranceTracker
import com.example.ui.settings.rememberMotionEnabled
import com.example.ui.theme.LocalGlassTheme
import com.example.ui.theme.OutfitFontFamily
import com.example.ui.theme.PlusJakartaSansFontFamily
import com.example.ui.viewmodel.AttendanceViewModel

/** Stateful host: reads the ViewModel (read-only) and owns the list/details back stack. */
@Composable
fun BunkPlannerScreen(viewModel: AttendanceViewModel) {
    val glass = LocalGlassTheme.current
    val profile by viewModel.profile.collectAsState()
    val result by viewModel.bunkPlannerResult.collectAsState()
    var detailRank by rememberSaveable { mutableStateOf<Int?>(null) }

    BackHandler {
        if (detailRank != null) detailRank = null else viewModel.closeBunkPlanner()
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(glass.canvasStart, glass.canvasEnd)))
    ) {
        if (glass.isDark && profile.starfieldAnimationEnabled) {
            StarfieldCanvas(modifier = Modifier.fillMaxSize(), enabled = true)
        }
        BunkPlannerContent(
            result = result,
            detailRank = detailRank,
            onOpenDetails = { detailRank = it },
            onCloseDetails = { detailRank = null },
            onBack = { viewModel.closeBunkPlanner() },
            onRefresh = { detailRank = null; viewModel.recalculateBunkPlanner() }
        )
    }
}

/** Stateless content so it can be previewed and UI-tested with a fixed [BunkPlannerResult]. */
@Composable
fun BunkPlannerContent(
    result: BunkPlannerResult?,
    detailRank: Int?,
    onOpenDetails: (Int) -> Unit,
    onCloseDetails: () -> Unit,
    onBack: () -> Unit,
    onRefresh: () -> Unit
) {
    val motion = rememberMotionEnabled()
    val ready = result as? BunkPlannerResult.Ready
    val detailOption = detailRank?.let { r -> ready?.options?.firstOrNull { it.rank == r } }
    AnimatedContent(
        targetState = detailOption?.rank,
        transitionSpec = {
            if (!motion) fadeIn(tween(0)) togetherWith fadeOut(tween(0))
            else {
                val dir = if (targetState != null) 1 else -1
                (fadeIn(tween(260, delayMillis = 60)) +
                    slideInHorizontally(tween(340, easing = FastOutSlowInEasing)) { dir * it / 8 }) togetherWith
                    (fadeOut(tween(140)) + slideOutHorizontally(tween(260, easing = FastOutSlowInEasing)) { -dir * it / 8 })
            }
        },
        label = "bunkPlannerNav"
    ) { rank ->
        val option = rank?.let { r -> ready?.options?.firstOrNull { it.rank == r } }
        if (option != null && ready != null) {
            BunkOptionDetails(option = option, overview = ready.overview, onBack = onCloseDetails)
        } else {
            BunkPlannerList(result, onOpenDetails, onBack, onRefresh)
        }
    }
}

@Composable
private fun BunkPlannerList(
    result: BunkPlannerResult?,
    onOpenDetails: (Int) -> Unit,
    onBack: () -> Unit,
    onRefresh: () -> Unit
) {
    val glass = LocalGlassTheme.current
    val tracker = rememberEntranceTracker()
    LazyColumn(
        modifier = Modifier.fillMaxSize().testTag("bunk_planner_list"),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(start = 20.dp, end = 20.dp, bottom = 40.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { PlannerHeader(onBack, onRefresh) }
        when (result) {
            null -> item { LoadingState() }
            is BunkPlannerResult.Ready -> {
                item { Box(Modifier.loadIn(0, tracker)) { OverviewCard(result.overview) } }
                result.overview.takeIf { it.isProvisional || it.belowTargetNow }?.let { ov ->
                    item { Box(Modifier.loadIn(1, tracker)) { WarningCard(ov) } }
                }
                item { Box(Modifier.loadIn(2, tracker)) { AssumptionNote(result.overview) } }
                result.options.forEachIndexed { i, option ->
                    item(key = "opt_${option.rank}") {
                        Box(Modifier.loadIn(3 + i, tracker, key = 3 + i)) { RecommendationCard(option) { onOpenDetails(option.rank) } }
                    }
                }
                if (result.options.size < 3) {
                    item {
                        Text(
                            "Only ${result.options.size} safe option${if (result.options.size == 1) "" else "s"} found this month. " +
                                "No other full-day leave keeps projected attendance at or above your targets.",
                            fontFamily = PlusJakartaSansFontFamily, fontSize = 12.sp, color = glass.textMuted,
                            modifier = Modifier.testTag("bunk_fewer_note")
                        )
                    }
                }
            }
            is BunkPlannerResult.NoSafeOption -> {
                item { Box(Modifier.loadIn(0, tracker)) { OverviewCard(result.overview) } }
                item { Box(Modifier.loadIn(1, tracker)) { NoSafeState(result) } }
            }
            is BunkPlannerResult.InsufficientData -> {
                result.overview?.let { ov -> item { Box(Modifier.loadIn(0, tracker)) { OverviewCard(ov) } } }
                item { Box(Modifier.loadIn(1, tracker)) { MessageState("Not enough data yet", result.message, glass.amberGold, "bunk_insufficient") } }
            }
            is BunkPlannerResult.NoRemainingClasses -> {
                result.overview?.let { ov -> item { Box(Modifier.loadIn(0, tracker)) { OverviewCard(ov) } } }
                item {
                    Box(Modifier.loadIn(1, tracker)) {
                        MessageState(
                            "No classes left this month",
                            "There are no remaining scheduled classes before month end, so there is nothing to plan. Check back next month.",
                            glass.royalIndigo, "bunk_no_remaining"
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun PlannerHeader(onBack: () -> Unit, onRefresh: () -> Unit) {
    val glass = LocalGlassTheme.current
    Row(
        Modifier.fillMaxWidth().statusBarsPadding().padding(top = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(40.dp).clip(CircleShape).background(glass.cardSurface).clickable(onClick = onBack).testTag("bunk_back"),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = glass.textPrimary) }
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text("Bunk Planner", fontFamily = OutfitFontFamily, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = glass.textPrimary)
            Text(
                "Your top 3 safest full-day breaks this month",
                fontFamily = PlusJakartaSansFontFamily, fontSize = 12.sp, color = glass.textSecondary
            )
        }
        Box(
            Modifier.size(40.dp).clip(CircleShape).background(glass.cardSurface).clickable(onClick = onRefresh).testTag("bunk_refresh"),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Default.Refresh, contentDescription = "Recalculate", tint = glass.textPrimary) }
    }
}

@Composable
private fun LoadingState() {
    val glass = LocalGlassTheme.current
    BunkGlassCard(Modifier.testTag("bunk_loading")) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.5.dp, color = glass.royalIndigo)
            Spacer(Modifier.size(12.dp))
            Column {
                Text("Analysing your attendance", fontFamily = OutfitFontFamily, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, color = glass.textPrimary)
                Text("Reading timetable, holidays and targets…", fontFamily = PlusJakartaSansFontFamily, fontSize = 12.sp, color = glass.textMuted)
            }
        }
    }
}

@Composable
private fun OverviewCard(o: BunkOverview) {
    val glass = LocalGlassTheme.current
    BunkGlassCard(Modifier.testTag("bunk_overview")) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("${o.monthLabel} so far", fontFamily = PlusJakartaSansFontFamily, fontSize = 11.sp, color = glass.textMuted)
            val cur = o.currentPercent
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatBlock(
                    "Attendance now", if (cur != null) "${pct(cur)}%" else "—",
                    if (cur != null) pctColor(glass, cur, o.examTarget, o.stipendTarget) else glass.textMuted,
                    Modifier.weight(1f)
                )
                StatBlock("Target", "${o.requiredTarget}%", glass.textPrimary, Modifier.weight(1f), "Exam ${o.examTarget}% · Stipend ${o.stipendTarget}%")
                StatBlock("Classes left", o.remainingSessions.toString(), glass.textPrimary, Modifier.weight(1f), "${o.bunkEligibleDays} leave-eligible days")
            }
            if (cur != null) {
                AttendanceBar(cur, o.requiredTarget, pctColor(glass, cur, o.examTarget, o.stipendTarget))
                val margin = cur - o.requiredTarget
                Text(
                    "Margin now: ${signed(margin)} points · buffer ${o.safetyBuffer} pts",
                    fontFamily = PlusJakartaSansFontFamily, fontSize = 11.sp, color = glass.textSecondary
                )
            }
        }
    }
}

@Composable
private fun WarningCard(o: BunkOverview) {
    val glass = LocalGlassTheme.current
    BunkGlassCard(Modifier.testTag("bunk_warning"), accent = glass.amberGold) {
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            if (o.isProvisional) {
                Text("Provisional recommendations", fontFamily = OutfitFontFamily, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = glass.amberGold)
                Text(
                    "${o.unmarkedPastSessions} past ${if (o.unmarkedPastSessions == 1) "class is" else "classes are"} still unmarked and " +
                        "not counted. Mark them in Attendance for a definitive result. Until then these options are not guaranteed safe.",
                    fontFamily = PlusJakartaSansFontFamily, fontSize = 12.sp, color = glass.textSecondary
                )
            }
            if (o.belowTargetNow) {
                Text("You are currently below your target", fontFamily = OutfitFontFamily, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = glass.crimsonRose)
                Text(
                    "Only options whose full month-end projection reaches the target are shown.",
                    fontFamily = PlusJakartaSansFontFamily, fontSize = 12.sp, color = glass.textSecondary
                )
            }
        }
    }
}

@Composable
private fun AssumptionNote(o: BunkOverview) {
    val glass = LocalGlassTheme.current
    Text(
        "Month-end projection for ${o.monthLabel}, not an all-time forecast. Projected attendance if you attend all other " +
            "scheduled classes and take this leave. Future attendance is not guaranteed.",
        fontFamily = PlusJakartaSansFontFamily, fontSize = 11.5.sp, color = glass.textMuted,
        modifier = Modifier.testTag("bunk_assumption")
    )
}

@Composable
private fun RecommendationCard(option: BunkOption, onDetails: () -> Unit) {
    val glass = LocalGlassTheme.current
    val motion = rememberMotionEnabled()
    val accent = rankAccent(glass, option.rank)
    var shown by remember { mutableStateOf(!motion) }
    LaunchedEffect(Unit) { shown = true }
    val badgeScale by animateFloatAsState(
        if (shown) 1f else 0.4f, spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium), label = "rankBadge"
    )
    BunkGlassCard(Modifier.testTag("bunk_card_${option.rank}"), accent = accent) {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(34.dp).graphicsLayer { scaleX = badgeScale; scaleY = badgeScale }
                        .clip(CircleShape).background(accent.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) { Text("${option.rank}", fontFamily = OutfitFontFamily, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = accent) }
                Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                    Text(rankTitle(option.rank), fontFamily = PlusJakartaSansFontFamily, fontSize = 11.sp, color = accent, fontWeight = FontWeight.SemiBold)
                    Text(rangeLabel(option.start, option.end), fontFamily = OutfitFontFamily, fontSize = 17.sp, fontWeight = FontWeight.Bold, color = glass.textPrimary)
                }
                Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("${option.calendarDays} days off", fontFamily = OutfitFontFamily, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = glass.textPrimary)
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        TierChip(option.tier)
                        if (option.isProvisional) BunkChip("Provisional", glass.amberGold)
                    }
                }
            }

            DateStrip(option)
            StripLegend()

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatBlock("Working days missed", option.workingDaysMissed.toString(), glass.textPrimary, Modifier.weight(1f))
                StatBlock("Classes missed", option.classesMissed.toString(), glass.textPrimary, Modifier.weight(1f))
                StatBlock(
                    "Projected", "${pct(option.projectedPercent)}%",
                    glass.emeraldNeon, Modifier.weight(1f),
                    "Target ${option.requiredTarget}% · ${signed(option.marginPoints)}"
                )
            }

            SubjectRiskLine(option)

            Box(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(accent.copy(alpha = 0.18f))
                    .clickable(onClick = onDetails).padding(vertical = 11.dp).testTag("bunk_details_${option.rank}"),
                contentAlignment = Alignment.Center
            ) { Text("View Details", fontFamily = OutfitFontFamily, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = accent) }
        }
    }
}

@Composable
private fun SubjectRiskLine(option: BunkOption) {
    val glass = LocalGlassTheme.current
    val weakest = option.weakestSubject
    val text: String
    val color: Color
    if (weakest == null) {
        text = "No subject affected"; color = glass.textMuted
    } else if (option.subjectWarningCount == 0) {
        text = "All affected subjects stay on track · weakest ${weakest.subject.shortName} ${pct(weakest.projectedPercent)}%"
        color = glass.emeraldNeon
    } else {
        text = "Subject warning: ${option.subjects.filter { it.status != SubjectStatus.ON_TRACK }
            .joinToString(", ") { "${it.subject.shortName} ${pct(it.projectedPercent)}%" }} below target"
        color = if (option.subjects.any { it.status == SubjectStatus.BELOW_EXAM }) glass.crimsonRose else glass.amberGold
    }
    Text(text, fontFamily = PlusJakartaSansFontFamily, fontSize = 12.sp, fontWeight = FontWeight.Medium, color = color,
        modifier = Modifier.testTag("bunk_risk_${option.rank}"))
}

@Composable
private fun NoSafeState(r: BunkPlannerResult.NoSafeOption) {
    val glass = LocalGlassTheme.current
    val o = r.overview
    val reasonText = when (r.reason) {
        NoSafeReason.BELOW_TARGET_EVEN_IF_ATTEND_ALL ->
            "Even if you attend every remaining class, month-end attendance would be ${o.attendAllProjectedPercent?.let { pct(it) } ?: "—"}%, " +
                "below your required ${o.requiredTarget}%. Any leave would lower it further."
        NoSafeReason.EVERY_LEAVE_TOO_COSTLY ->
            "Every possible full-day leave would drop month-end attendance below ${o.requiredTarget}%." +
                (r.closestProjectedPercent?.let { " The gentlest option (${r.closestDates.joinToString { d -> "${d.dayOfMonth} ${shortMonth(d)}" }}) would end at ${pct(it)}%." } ?: "")
        NoSafeReason.NO_ELIGIBLE_DAYS ->
            "There are no remaining upcoming days with a manually attended class, so there is no full-day leave to evaluate."
    }
    BunkGlassCard(Modifier.testTag("bunk_no_safe"), accent = glass.crimsonRose) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("No safe option available", fontFamily = OutfitFontFamily, fontWeight = FontWeight.Bold, fontSize = 17.sp, color = glass.crimsonRose)
            Text(reasonText, fontFamily = PlusJakartaSansFontFamily, fontSize = 13.sp, color = glass.textSecondary)
            if (r.weakSubjects.isNotEmpty()) {
                Text("Subjects already short of target this month: ${r.weakSubjects.joinToString()}.",
                    fontFamily = PlusJakartaSansFontFamily, fontSize = 12.sp, color = glass.amberGold)
            }
            Text("${o.remainingSessions} classes remain before month end. No unsafe dates are shown as recommendations.",
                fontFamily = PlusJakartaSansFontFamily, fontSize = 12.sp, color = glass.textMuted)
            if (o.isProvisional) {
                Text("${o.unmarkedPastSessions} past classes are unmarked; marking them may change this result.",
                    fontFamily = PlusJakartaSansFontFamily, fontSize = 12.sp, color = glass.amberGold)
            }
        }
    }
}

@Composable
private fun MessageState(title: String, body: String, accent: Color, tag: String) {
    val glass = LocalGlassTheme.current
    BunkGlassCard(Modifier.testTag(tag), accent = accent) {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(title, fontFamily = OutfitFontFamily, fontWeight = FontWeight.Bold, fontSize = 17.sp, color = accent)
            Text(body, fontFamily = PlusJakartaSansFontFamily, fontSize = 13.sp, color = glass.textSecondary)
        }
    }
}
