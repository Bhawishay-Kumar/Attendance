BHTT Attendance Companion - Latest Build APK
=============================================
Status: Build Succeeded (All v7 + What-If Predictor + Bunk Planner features included)
Package: com.aistudio.bhtt.attendance
Build Date: Nov 3, 2026

Features Included:
- Native Full-screen Bunk Planner (Top 3 Safest Breaks, exact raw ratios, safety buffer tiers, subject warnings)
- Native Full-screen What-If Predictor (Plan Only & Month End modes)
- Smart Recovery Suggestions & Real Recalculations
- Saved Scenarios & Side-by-Side Comparison (with mismatch alerts)
- Home and Reports Smart Tools integrations
- Live 30s ticking clock & "ALL DONE" / Concluded states
- High-contrast day/night themes (Pearl Lavender & Midnight Velvet)
- Verified weighted credits and AKTU Academic Calendar support

Test Status:
- 108 tests executed, 108 passed, 0 failed.
- BunkPlannerEngineTest: 15/15 passed
- BunkPlannerUiTest: 7/7 passed

Files:
- app-debug.apk (37 MB)
- BHTT-Attendance-Companion.apk (37 MB)

How to download/install:
- Right-click or use the file explorer download option in AI Studio to save the APK to your device.
